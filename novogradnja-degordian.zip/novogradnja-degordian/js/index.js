
        $(document).ready(function(){
            $('.slider').slick({
              dots: true,
              arrows: true,
              autoplay: true,
              autoplaySpeed: 5000
    
            });
          });

